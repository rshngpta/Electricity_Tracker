# Lambda Handlers for Electricity Tracker

